package StepDefinitions;
import org.openqa.selenium.WebDriver;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.chrome.ChromeDriver;


public class LoginSteps {

    WebDriver driver = null;

    @Given("Browser is open")
    public void browserIsOpen() {
        System.setProperty("webdriver.chrome.driver", "/Users/kacharya/Projects/wynshop/src/test/resources/drivers/chromedriver.exe");
        driver = new ChromeDriver();
    }

    @And("User is on the login page")
    public void user_is_on_the_login_page() {
        System.out.println("User is on the login page");
       //driver.navigate().to("https://wynshop-f8268.web.app/login");
    }

    @When("User enters user1 and password1")
    public void user_enters_user1_and_password1() {
        System.out.println("User is entering username and password");
    }

    @And("User clicks on the login button")
    public void user_clicks_on_the_login_button() {
        System.out.println("User is clicking on the login button");
    }

    @Then("User is navigated to the home page")
    public void user_is_navigated_to_the_home_page() {
        System.out.println("User is navigated to the home page");
    }


}
